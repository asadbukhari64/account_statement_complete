package com.maybank.account.statement.model;

public class AccountDetailsDTO {
	 
	    private String accountNumber;
	    private String trxAmount;
	    private String description;
	    private String trxDate;
	    private String trxTime;
	    private String customerId;
		public AccountDetailsDTO(String accountNumber, String trxAmount, String description, String trxDate, String trxTime,
				String customerId) {
		this.accountNumber=accountNumber;
		this.trxAmount=trxAmount;
		this.description=description;
		this.trxDate=trxDate;;
		this.trxTime=trxTime;
		this.customerId=customerId;
		}
		/**
		 * @return the accountNumber
		 */
		public String getAccountNumber() {
			return accountNumber;
		}
		/**
		 * @param accountNumber the accountNumber to set
		 */
		public void setAccountNumber(String accountNumber) {
			this.accountNumber = accountNumber;
		}
		/**
		 * @return the trxAmount
		 */
		public String getTrxAmount() {
			return trxAmount;
		}
		/**
		 * @param trxAmount the trxAmount to set
		 */
		public void setTrxAmount(String trxAmount) {
			this.trxAmount = trxAmount;
		}
		/**
		 * @return the description
		 */
		public String getDescription() {
			return description;
		}
		/**
		 * @param description the description to set
		 */
		public void setDescription(String description) {
			this.description = description;
		}
		/**
		 * @return the trxDate
		 */
		public String getTrxDate() {
			return trxDate;
		}
		/**
		 * @param trxDate the trxDate to set
		 */
		public void setTrxDate(String trxDate) {
			this.trxDate = trxDate;
		}
		/**
		 * @return the trxTime
		 */
		public String getTrxTime() {
			return trxTime;
		}
		/**
		 * @param trxTime the trxTime to set
		 */
		public void setTrxTime(String trxTime) {
			this.trxTime = trxTime;
		}
		/**
		 * @return the customerId
		 */
		public String getCustomerId() {
			return customerId;
		}
		/**
		 * @param customerId the customerId to set
		 */
		public void setCustomerId(String customerId) {
			this.customerId = customerId;
		}

	     
	}



