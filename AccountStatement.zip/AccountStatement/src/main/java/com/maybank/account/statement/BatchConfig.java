package com.maybank.account.statement;

import com.maybank.account.statement.model.AccountDetailsEntity;
import com.maybank.account.statement.model.AccountDetailsRepository;
import com.maybank.account.statement.service.AccountProcessor;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.job.builder.JobBuilder;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.batch.core.repository.JobRepository;
import org.springframework.batch.core.step.builder.StepBuilder;
import org.springframework.batch.item.ItemWriter;
import org.springframework.batch.item.database.JdbcBatchItemWriter;
import org.springframework.batch.item.file.FlatFileItemReader;
import org.springframework.batch.item.file.builder.FlatFileItemReaderBuilder;
import org.springframework.batch.item.file.mapping.BeanWrapperFieldSetMapper;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.ClassPathResource;
import org.springframework.transaction.PlatformTransactionManager;

@Configuration
@EnableBatchProcessing
public class BatchConfig {
	@Value("${data.source}")
	private String dataSource;

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Bean
	public FlatFileItemReader reader() {
		return new FlatFileItemReaderBuilder().name("batchFileReaderJob").resource(new ClassPathResource(dataSource))
				.linesToSkip(1).delimited().delimiter("|")
				.names(new String[] { "accountNumber", "trxAmount", "description", "trxDate", "trxTime", "customerId" })
				.fieldSetMapper(new BeanWrapperFieldSetMapper() {
					{
						setTargetType(AccountDetailsEntity.class);
					}
				}).build();
	}

	@Bean
	public ItemWriter<AccountDetailsEntity> writer(AccountDetailsRepository repository) {
		return repository::saveAll;
	}

	@Bean
	public Job importUserJob(JobRepository jobRepository, JobCompletionNotificationListener listener, Step step1) {
		return new JobBuilder("batchFileReaderJob", jobRepository).incrementer(new RunIdIncrementer())
				.listener(listener).flow(step1).end().build();
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Bean
	public Step step1(JobRepository jobRepository, PlatformTransactionManager transactionManager, ItemWriter writer) {
		return new StepBuilder("step1", jobRepository)
				.<AccountDetailsEntity, AccountDetailsEntity>chunk(10, transactionManager).reader(reader())
				.processor(processor()).writer(writer).build();
	}

	@Bean
	public AccountProcessor processor() {
		return new AccountProcessor();
	}
}
