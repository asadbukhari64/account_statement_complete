package com.maybank.account.statement.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;

@Embeddable
public class AccountDetailsKey implements Serializable {

	private static final long serialVersionUID = 1L;

	public AccountDetailsKey() {}
	public AccountDetailsKey(String accountNumber, String trxAmount, String trxDate, String trxTime,
			String customerId) {
		super();
		this.accountNumber = accountNumber;
		this.trxAmount = trxAmount;
		this.trxDate = trxDate;
		this.trxTime = trxTime;
		this.customerId = customerId;
	}

	@Column(name = "ACCOUNT_NUMBER")
	private String accountNumber;
	
	@Column(name = "ARX_AMOUNT")
	private String trxAmount;
	
	@Column(name = "TRX_DATE")
	private String trxDate;
	
	@Column(name = "TRX_TIME")
	private String trxTime;
	
	@Column(name = "CUSTOMER_ID")
	private String customerId;

	/**
	 * @return the accountNumber
	 */
	public String getAccountNumber() {
		return accountNumber;
	}

	/**
	 * @param accountNumber the accountNumber to set
	 */
	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}

	/**
	 * @return the trxAmount
	 */
	public String getTrxAmount() {
		return trxAmount;
	}

	/**
	 * @param trxAmount the trxAmount to set
	 */
	public void setTrxAmount(String trxAmount) {
		this.trxAmount = trxAmount;
	}

	/**
	 * @return the trxDate
	 */
	public String getTrxDate() {
		return trxDate;
	}

	/**
	 * @param trxDate the trxDate to set
	 */
	public void setTrxDate(String trxDate) {
		this.trxDate = trxDate;
	}

	/**
	 * @return the trxTime
	 */
	public String getTrxTime() {
		return trxTime;
	}

	/**
	 * @param trxTime the trxTime to set
	 */
	public void setTrxTime(String trxTime) {
		this.trxTime = trxTime;
	}

	/**
	 * @return the customerId
	 */
	public String getCustomerId() {
		return customerId;
	}

	/**
	 * @param customerId the customerId to set
	 */
	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

}
