package com.maybank.account.statement.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.item.ItemProcessor;

import com.maybank.account.statement.model.AccountDetailsEntity;

public class AccountProcessor  implements ItemProcessor<AccountDetailsEntity, AccountDetailsEntity> {

 

	    private static final Logger LOGGER = LoggerFactory.getLogger(AccountProcessor.class);
 

	@Override
	public AccountDetailsEntity process(final AccountDetailsEntity account) throws Exception {
		
		AccountDetailsEntity accountDetails = new AccountDetailsEntity(
				account.getAccountNumber(), account.getTrxAmount(), account.getDescription(), account.getTrxDate(),
				account.getTrxTime(), account.getCustomerId());
        LOGGER.info("Converting ( {} ) into ( {} )", account, accountDetails);

		return accountDetails;
	}
}
