package com.maybank.account.statement.service;

import java.util.List;

import com.maybank.account.statement.model.AccountDetailsEntity;
 
public interface AccountDetailsService {

 
    AccountDetailsEntity createProduct(AccountDetailsEntity product);

    AccountDetailsEntity updateAccount(AccountDetailsEntity product);

    List < AccountDetailsEntity > getAllProduct();

    AccountDetailsEntity getProductById(long productId);
    
     List < AccountDetailsEntity > findByDescription(String description);
    
    List < AccountDetailsEntity > findByCustomerId(String customerId);

    void deleteProduct(long id);

	List<AccountDetailsEntity> findByAccountNumber(String accountNumber);
}

