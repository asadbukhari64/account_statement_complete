package com.maybank.account.statement.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.maybank.account.statement.exception.ResourceNotFoundException;
import com.maybank.account.statement.model.AccountDetailsEntity;
import com.maybank.account.statement.model.AccountDetailsRepository;

@Service
public class AccountDetailsImpl implements AccountDetailsService {

    @Autowired
    private AccountDetailsRepository accountDetailsRepository;
	
	@Override
	@Transactional
	public AccountDetailsEntity createProduct(AccountDetailsEntity account) {
        return accountDetailsRepository.save(account);
 	}

	@Override
	@Transactional
	public AccountDetailsEntity updateAccount(AccountDetailsEntity account) {
        Optional<AccountDetailsEntity> accountUpdate = this.accountDetailsRepository.findByIdWithLock(account.getId());
        if (accountUpdate.isPresent()) {
        	AccountDetailsEntity productUpdate = accountUpdate.get();

        	productUpdate.setDescription(account.getDescription());

//        	productUpdate.setAccountNumber(account.getAccountNumber());
//        	productUpdate.setCustomerId(account.getCustomerId());
//        	productUpdate.setTrxAmount(account.getTrxAmount());
//        	productUpdate.setTrxDate(account.getTrxDate());
//        	productUpdate.setTrxTime(account.getTrxTime());
        	
            accountDetailsRepository.save(productUpdate);
            return productUpdate;
        } else {
            throw new ResourceNotFoundException("Record not found ");
        }
    }
           

	@Override
	public List<AccountDetailsEntity> getAllProduct() {
        return this.accountDetailsRepository.findAll();
 	}

	@Override
	public AccountDetailsEntity getProductById(long productId) {
	      Optional < AccountDetailsEntity > productDb = this.accountDetailsRepository.findById(productId);

	        if (productDb.isPresent()) {
	            return productDb.get();
	        } else {
	            throw new ResourceNotFoundException("Record not found with id : " + productId);
	        }
	    }

	

	@Override
	public void deleteProduct(long id) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<AccountDetailsEntity> findByCustomerId(String customerId) {

		 List < AccountDetailsEntity > productDb = this.accountDetailsRepository.findByCustomerId(customerId);

	        if (productDb!=null && !productDb.isEmpty()) {
	            return productDb;
	        } else {
	            throw new ResourceNotFoundException("Record not found with id : " + customerId);
	        }
	    
	}
	

	
	@Override
	public List<AccountDetailsEntity> findByDescription(String description) {

		 List < AccountDetailsEntity > productDb = this.accountDetailsRepository.findByDescription(description);

	        if (productDb!=null && !productDb.isEmpty()) {
	            return productDb;
	        } else {
	            throw new ResourceNotFoundException("Record not found with description : " + description);
	        }
	    
	}

//	@Override
//	public AccountDetailsEntity updateAccount(AccountDetailsEntity product) {
//		AccountDetailsEntity accountDetailsEntity=this.accountDetailsRepository.findById(product.getId());
//		
//		if(accountDetailsEntity!=null) {
//			accountDetailsEntity.setDescription(product.getDescription());
//			
//			this.accountDetailsRepository.save(accountDetailsEntity);
//		} else {
//            throw new ResourceNotFoundException("Record not found");
//        }
//		
//		
//		return accountDetailsEntity;
//		 
//	}

	@Override
	public List<AccountDetailsEntity> findByAccountNumber(String accountNumber) {
  
			 List < AccountDetailsEntity > productDb = this.accountDetailsRepository.findByAccountNumber(accountNumber);

		        if (productDb!=null && !productDb.isEmpty()) {
		            return productDb;
		        } else {
		            throw new ResourceNotFoundException("Record not found with accountNumber : " + accountNumber);
		        }
		    
		}
	

	 

}
