package com.maybank.account.statement;
 

import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.launch.JobLauncher;
 
  
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class BatchJobRunner {

    private final JobLauncher jobLauncher;
    private final Job batchFileReaderJob; 

    public BatchJobRunner(JobLauncher jobLauncher, Job importUserJob) {
        this.jobLauncher = jobLauncher;
        this.batchFileReaderJob = importUserJob;
    }

   
     @Bean
    public CommandLineRunner runJob() {
        return args -> {
            jobLauncher.run(batchFileReaderJob, new JobParametersBuilder()
                    .addLong("startAt", System.currentTimeMillis())
                    .toJobParameters());
        };
    }
}

