package com.maybank.account.statement.controller;

import java.io.UnsupportedEncodingException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URLEncoder;

public class URLConverter {
    public static void main(String[] args) {
        try {
            // Original URL
            String originalUrl = "http://localhost:8081:Retail-Customer-Services/profile/v1/customers/2312321423423523523/contacts";
            
            // Parse the original URL
            URI uri = new URI(originalUrl);
            
            // Extract the path segments
            String[] pathSegments = uri.getPath().split("/");
            
            // Extract the base path up to the resource before the ID
            StringBuilder basePath = new StringBuilder();
            for (int i = 1; i < pathSegments.length - 2; i++) {
                basePath.append("/").append(pathSegments[i]);
            }
            
            // Extract the resource name dynamically
            String resourceName = pathSegments[pathSegments.length - 2];
            
            // Build the new path dynamically based on the original resource name
            String newPath = basePath.append("/" + resourceName + "es").toString(); // Assuming plural form is "resourceName" + "es"
            
            // Extract the customer ID
            String customerId = pathSegments[pathSegments.length - 1];
            
            // Build the new query string
            String filterParam = String.format("filter[customers]=%s", URLEncoder.encode(customerId, "UTF-8"));
            
            // Construct the new URI
            URI newUri = new URI(uri.getScheme(), uri.getAuthority(), newPath, filterParam, null);
            
            // Output the new URL
            String newUrl = newUri.toString();
            System.out.println("New URL: " + newUrl);
        } catch (URISyntaxException | UnsupportedEncodingException e) {
            e.printStackTrace();
        }
    }
}
