package com.maybank.account.statement.model;

import java.io.Serializable;


import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
 

@Entity
@Table(name = "accounts")
public class AccountDetailsEntity implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	  
	

	/**
	 * @return the id
	 */
	public Long getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(Long id) {
		this.id = id;
	}

	public AccountDetailsEntity() {
	}

	@Column(name = "ACCOUNT_NUMBER")
	private String accountNumber;

	public AccountDetailsEntity(String accountNumber, String trxAmount, String description, String trxDate,
			String trxTime, String customerId) {
		super();
		this.id = id;
		this.accountNumber = accountNumber;
		this.trxAmount = trxAmount;
		this.description = description;
		this.trxDate = trxDate;
		this.trxTime = trxTime;
		this.customerId = customerId;
	}

	@Column(name = "ARX_AMOUNT")
	private String trxAmount;


	@Column(name = "DESCRIPTION")
	private String description;
	
	@Column(name = "TRX_DATE")
	private String trxDate;

	@Column(name = "TRX_TIME")
	private String trxTime;

	@Column(name = "CUSTOMER_ID")
	private String customerId;

	/**
	 * @return the accountNumber
	 */
	public String getAccountNumber() {
		return accountNumber;
	}

	/**
	 * @param accountNumber the accountNumber to set
	 */
	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}

	/**
	 * @return the trxAmount
	 */
	public String getTrxAmount() {
		return trxAmount;
	}

	/**
	 * @param trxAmount the trxAmount to set
	 */
	public void setTrxAmount(String trxAmount) {
		this.trxAmount = trxAmount;
	}

	/**
	 * @return the trxDate
	 */
	public String getTrxDate() {
		return trxDate;
	}

	/**
	 * @param trxDate the trxDate to set
	 */
	public void setTrxDate(String trxDate) {
		this.trxDate = trxDate;
	}

	/**
	 * @return the trxTime
	 */
	public String getTrxTime() {
		return trxTime;
	}

	/**
	 * @param trxTime the trxTime to set
	 */
	public void setTrxTime(String trxTime) {
		this.trxTime = trxTime;
	}

	/**
	 * @return the customerId
	 */
	public String getCustomerId() {
		return customerId;
	}

	/**
	 * @param customerId the customerId to set
	 */
	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	/**
	 * @return the serialversionuid
	 */
	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	/**
	 * @return the description
	 */
	public String getDescription() {
		return description;
	}

	/**
	 * @param description the description to set
	 */
	public void setDescription(String description) {
		this.description = description;
	}

}
