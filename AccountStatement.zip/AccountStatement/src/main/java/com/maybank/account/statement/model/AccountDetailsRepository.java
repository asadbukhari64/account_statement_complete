package com.maybank.account.statement.model;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Lock;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import jakarta.persistence.LockModeType;

 
public interface AccountDetailsRepository extends JpaRepository<AccountDetailsEntity, Long> {
	
 List < AccountDetailsEntity > findByCustomerId(String customerId);
 List < AccountDetailsEntity > findByAccountNumber(String accountNumber);
 List < AccountDetailsEntity > findByDescription(String description);
 Optional<AccountDetailsEntity> findById(Long id);
 // Optional<AccountDetailsEntity> findByIdWithLock(Long id);

 @Lock(LockModeType.PESSIMISTIC_WRITE)
 @Query("SELECT e FROM AccountDetailsEntity e WHERE e.id = :id")
 Optional<AccountDetailsEntity>findByIdWithLock(@Param("id") Long id);



}