package com.maybank.account.statement.controller;

import java.io.IOException;
import java.net.URISyntaxException;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.query.Param;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.maybank.account.statement.exception.ResourceNotFoundException;
import com.maybank.account.statement.model.AccountDetailsDTO;
import com.maybank.account.statement.model.AccountDetailsEntity;
import com.maybank.account.statement.model.AccountDetailsKey;
import com.maybank.account.statement.model.AccountDetailsRepository;
import com.maybank.account.statement.service.AccountDetailsService;

import jakarta.servlet.http.HttpServletRequest;

@RestController
@CrossOrigin(origins = "http://localhost:4200")

public class AccountStatementController {
	@Autowired
	private AccountDetailsService accountService;

	@GetMapping("/accounts/customerId/{customerId}")
	@ResponseBody
	public ResponseEntity<List<AccountDetailsEntity>> findByCustomerId(HttpServletRequest request,
			@PathVariable(value = "customerId", required = false) String customerId) throws ResourceNotFoundException {
		return ResponseEntity.ok().body(accountService.findByCustomerId(customerId));
	}

	@GetMapping("/accounts/description/{description}")
	@ResponseBody
	public ResponseEntity<List<AccountDetailsEntity>> findByDescription(HttpServletRequest request,
			@PathVariable(value = "description", required = false) String description)
			throws ResourceNotFoundException {
		return ResponseEntity.ok().body(accountService.findByDescription(description));
	}

	@GetMapping("/accounts/accountNumber/{accountNumber}")
	@ResponseBody
	public ResponseEntity<List<AccountDetailsEntity>> findByIdAccountNumber(HttpServletRequest request,
			@PathVariable(value = "accountNumber", required = false) String accountNumber)
			throws ResourceNotFoundException {
		return ResponseEntity.ok().body(accountService.findByAccountNumber(accountNumber));
	}

	@GetMapping(path = "/accounts", produces = "application/json")
	@ResponseBody
	public ResponseEntity<List<AccountDetailsEntity>> getAllProduct(HttpServletRequest request) {
		return ResponseEntity.ok().body(accountService.getAllProduct());
	}

	@PostMapping("/accounts")
	public AccountDetailsEntity updateAccount(@RequestBody AccountDetailsEntity accounts) {
		System.out.println("called");
		return accountService.updateAccount(accounts);
	}
 	@PostMapping("/accounts/createAccount")
	public AccountDetailsEntity createProduct(@RequestBody AccountDetailsEntity accounts) {
		System.out.println("createProduct");
		return accountService.createProduct(accounts);
	}
	
	
}