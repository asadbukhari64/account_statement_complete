//package com.maybank.account.statement.service;
//
//import java.io.IOException;
//import java.net.URISyntaxException;
//import java.net.URL;
//import java.nio.file.Files;
//import java.nio.file.Path;
//import java.util.List;
//import java.util.stream.Collectors;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Component;
//
//import com.maybank.account.statement.model.AccountDetailsDTO;
//import com.maybank.account.statement.model.AccountDetailsEntity;
//import com.maybank.account.statement.model.AccountDetailsKey;
//
//import jakarta.annotation.PostConstruct;
//
//@Component
//public class FileReader {
//
//	@Autowired
//	private AccountDetailsService accountService;
//
//	@PostConstruct
//	public void init() {
//
//		URL resource = getClass().getClassLoader().getResource("dataSource.txt");
//
//		try {
//			List<AccountDetailsEntity> records = Files.lines(Path.of(resource.toURI())).skip(1)
//					.map(line -> line.split("\\|")).map(data -> new AccountDetailsEntity
//							(data[0], // account number
//							data[1], // amount
//							data[2], // description
//							data[3], // trx date
//							data[4], // trx time
//							(data[5]// customer id
//							))).collect(Collectors.toList());
//			records.forEach(i -> accountService.createProduct(i));
//			
//
//
//		} catch (IOException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		} catch (URISyntaxException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//	}
//}