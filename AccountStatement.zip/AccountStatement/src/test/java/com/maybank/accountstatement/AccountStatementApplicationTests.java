package com.maybank.accountstatement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

class AccountStatementApplicationTests {

	void contextLoads() {
	}

}
