angular.module('myApp')
  .controller('accountController', ['$scope', 'myService', function($scope, myService) {
    
	  
	  
	  // Function to get data
    $scope.getData = function() {
      myService.getData().then(function(response) {
        $scope.accountDetails = response.data;
        $scope.applyPagination();
        $scope.selectedTransaction = {}; // Initialize selectedTransaction object

        // Function to set the selected transaction
        $scope.selectAccount = function(account) {
            $scope.selectedAccount = angular.copy(account); // Copy selected transaction to $scope.selectedTransaction
        };

        
        
      }).catch(function(error) {
        console.error('Error occurred:', error);
      });
    };

    $scope.totalPages= {};
    //pagination
    $scope.applyPagination=function(){
    $scope.currentPage = 1;
    $scope.pageSize = 5; // Number of items per page
    $scope.totalPages = Math.ceil($scope.accountDetails.length / $scope.pageSize);



    $scope.displayedTransactions = [];

    $scope.$watchGroup(['currentPage', 'pageSize'], function() {
        var startIndex = ($scope.currentPage - 1) * $scope.pageSize;
        $scope.accountDetailsDisplayed = $scope.accountDetails.slice(startIndex, startIndex + $scope.pageSize);
    });
    
  
    $scope.pages = [];
    for (var i = 1; i <= $scope.totalPages; i++) {
        $scope.pages.push(i);
    }
    
    };
    
    $scope.setPage = function(page) {
        if (page < 1 || page > $scope.totalPages) return;
        $scope.currentPage = page;
    };

    $scope.prevPage = function() {
        $scope.setPage($scope.currentPage - 1);
    };

    $scope.nextPage = function() {
        $scope.setPage($scope.currentPage + 1);
    };
    // Function to post data
    $scope.postData = function() {
      const dataToPost = {
        key: 'value'
      };
      
     

      myService.postData(dataToPost).then(function(response) {
        $scope.response = response.data;
      }).catch(function(error) {
        console.error('Error occurred:', error);
      });
    };
    
    $scope.updateAccount = function() {
        // Here you can implement the logic to update the transaction (e.g., send an API request)
        console.log('Updated Transaction:', $scope.selectedAccount);
        // After updating, you might want to clear the selection
        
        myService.postData($scope.selectedAccount).then(function(response) {
            $scope.response = response.data;
          }).catch(function(error) {
            console.error('Error occurred:', error);
          });
          
        $scope.selectedAccount = null;
    };
    
    
    $scope.createAccount = function() {
        // Here you can implement the logic to update the transaction (e.g., send an API request)
        console.log('createAccount:', $scope.selectedAccount);
        // After updating, you might want to clear the selection
        
        myService.createAccount($scope.selectedAccount).then(function(response) {
            $scope.response = response.data;
          }).catch(function(error) {
            console.error('Error occurred:', error);
          });
          
        $scope.selectedAccount = null;
    };
    // Function to cancel the update
    $scope.cancelUpdate = function() {
        // Simply clear the selectedTransaction to cancel the update
        $scope.selectedAccount = null;
    };
    
    
    $scope.findAccount = function() {
        myService.findAccount($scope.selectedAccount).then(function(response) {
          $scope.accountDetails = response.data;
          $scope.applyPagination();
          $scope.selectedTransaction = {}; // Initialize selectedTransaction object

          // Function to set the selected transaction
          $scope.selectAccount = function(account) {
              $scope.selectedAccount = angular.copy(account); // Copy selected transaction to $scope.selectedTransaction
          };

          
          
        }).catch(function(error) {
          console.error('Error occurred:', error);
        });
      };

      
      $scope.findByAccountNumber = function() {
    	
    	  
          myService.findByAccountNumber($scope.selectedAccount).then(function(response) {
            $scope.accountDetails = response.data;
            $scope.applyPagination();
            $scope.selectedTransaction = {}; // Initialize selectedTransaction object

            // Function to set the selected transaction
            $scope.selectAccount = function(account) {
                $scope.selectedAccount = angular.copy(account); // Copy selected transaction to $scope.selectedTransaction
            };

            
            
          }).catch(function(error) {
            console.error('Error occurred:', error);
          });
        };

   
    
    
  }]);
