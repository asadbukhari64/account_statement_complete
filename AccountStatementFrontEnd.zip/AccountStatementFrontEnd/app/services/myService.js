angular.module('myApp', [])
  .service('myService', ['$http', function($http) {
   
	   
	  this.getData = function() {
 
		  const headers = {
		            'Content-Type': 'application/json',
		            'Access-Control-Allow-Origin': '*',
		           
		            'Access-Control-Allow-Methods': 'GET',
		            'Access-Control-Max-Age': ' 3600',
		            'Access-Control-Allow-Headers': 'access-control-allow-headers,access-control-allow-methods,access-control-allow-origin,access-control-max-age,x-api-key,x-api-secret',
			  'X-API-KEY': '123243242',
		      'X-API-SECRET':'SDQE21ESD1EQWXWEDWCER'
		        }

       return $http({
        method: 'GET',
        url: 'http://localhost:8080/accounts',
        headers: headers
      });
    };
    
    this.findAccount = function(data) {
    	var url= null;
  	  if( !isEmpty(data.accountNumber) && isEmpty(data.customerId) && isEmpty(data.description))
  	  { url= 'http://localhost:8080/accounts/accountNumber/'+data.accountNumber;
  	  }
    	
  	  else if( !isEmpty(data.customerId) && isEmpty(data.accountNumber) && isEmpty(data.description))
  	  { url= 'http://localhost:8080/accounts/customerId/'+data.customerId;}
  	  else if(!isEmpty(data.description) && isEmpty(data.accountNumber) && isEmpty(data.customerId) )
        { url= 'http://localhost:8080/accounts/description/'+data.description;}
    	
       if(isEmpty(url)) {
    	   return;
       }
        
  	  const headers = {
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': ' http://localhost:4200',
            'Access-Control-Allow-Credentials': 'true',
            'Access-Control-Allow-Methods': ' POST, GET, OPTIONS, DELETE',
            'Access-Control-Max-Age': ' 3600',
            'Access-Control-Allow-Headers': 'Content-Type, Accept, X-Requested-With, remember-me',
  'Authorization':
           'Bearer eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJoYXRlbTEyMyIsImF1dGgiOlt7ImF1dGhvcml0eSI6IlJPTEVfRU1Q',
	  'X-API-KEY': '123243242',
      'X-API-SECRET':'SDQE21ESD1EQWXWEDWCER'
        }

         return $http({
          method: 'GET',
          url:url,
          headers: headers
        });
      };

    this.postData = function(data) {
    	 const headers = {
    		        'X-API-KEY': '123243242',
    		        'X-API-SECRET':'SDQE21ESD1EQWXWEDWCER'
    		        	 
    		      };

      return $http({
        method: 'POST',
        url: 'http://localhost:8080/accounts',
        headers: headers,
        data: data
      });
    };
    
    this.createAccount = function(data) {
   	 const headers = {
   		        'X-API-KEY': '123243242',
   		        'X-API-SECRET':'SDQE21ESD1EQWXWEDWCER'
   		        	 
   		      };

     return $http({
       method: 'POST',
       url: 'http://localhost:8080/accounts/createAccount',
       headers: headers,
       data: data
     });
   };
   function isEmpty(value){
	   return (value == undefined  || value == null || value.trim().length === 0);
	 }
   
  }]);
